#xpath for def parse_1st(self,response):
urls_xpath = '//td[@class="col_c_forum"]/h4/a/@href'



#xpath for def parse_next(self,response):
navigation_xpath = '//div[@class="topic_controls clearfix"]//li[@class="next"]//@href'
thread_urls_xpath = '//td[@class="col_f_content "]//h4//a//@href'



#xpath for meta data :
nodes_xpath = '//div[@class="post_wrap"]'

#text_xpath = './/div[@class="post entry-content "]/text() | .//iframe[@class="EmbeddedVideo"]//@alt | .//div[@class="post entry-content "]//span[@rel="lightbox"]//@alt | .//img[@class="attach"]//@src |  .//div[@itemprop="commentText"]//following-sibling::blockquote//@data-author |.//div[@class="post entry-content "]//p//text() | .//div[@class="post entry-content "]/text() | .//img[@class="bbc_emoticon"]//@alt |.//div[@class="post entry-content "]//span[@rel="lightbox"]//@alt | .//iframe[@class="EmbeddedVideo"]//img[@itemprop="image"]//@alt | .//div[@itemprop="commentText"]//following-sibling::blockquote//@data-time | .//iframe[@class="EmbeddedVideo"]//a[@class="bbc_url"]//@href | .//div[@class="post entry-content "]//a[@class="bbc_url"]//@href | .//iframe[@class="EmbeddedVideo"]//img[@itemprop="image"]//@alt | .//a[@title="Download attachment"]/@href'
text_xpath = './/div[@class="post entry-content "]/text() | .//iframe[@class="EmbeddedVideo"]//@alt | .//div[@class="post entry-content "]//span[@rel="lightbox"]//@alt | .//img[@class="attach"]//@src |  .//div[@itemprop="commentText"]//following-sibling::blockquote//@data-author'

data_times_xpath = './/div[@itemprop="commentText"]//following-sibling::blockquote//@data-time'


Category_xpath = '//span[@itemprop="title"]//text()'
Subcategory_xpath = '//span[@itemprop="title"]//text()'
ThreadTitle_xpath = '//h1[@class="ipsType_pagetitle"]//text()'
author_links_xpath = './/span[@class="author vcard"]//a//@href'
Post_url_xpath = './/span//a[@itemprop="replyToUrl"]//@href'
PublishTime_xpath = './/div[@class="post_body"]//p[@class="posted_info desc lighter ipsType_small"]//abbr//text()'
Author_xpath = './/span[@itemprop="name"]//text()'

#Links_xpath = './/div[@class="post entry-content "]//a[@class="bbc_url"]//@href | .//iframe[@class="EmbeddedVideo"]//img[@itemprop="image"]//@src | .//div[@id="attach_wrap"]//a//@href  |  .//img[@class="attach"]//@src |.//div[@class="post entry-content "]//span[@rel="lightbox"]//@src | .//iframe[@class="EmbeddedVideo"]//@src | .//div[@class="post entry-content "]//li[@class="attachment"]//a[img]/@href | .//div[@itemprop="commentText"]//a[@class="bbc_url"]//@href | .//div[@itemprop="commentText"]//a[@class="bbc_url"]//@href | .//div[@id="gifv"]//video/source/@src'

Links_xpath = './/div[@class="post entry-content "]//a[@class="bbc_url"]//@href | .//iframe[@class="EmbeddedVideo"]//img[@itemprop="image"]//@src | .//img[@class="attach"]//@src |.//div[@class="post entry-content "]//span[@rel="lightbox"]//@src | .//iframe[@class="EmbeddedVideo"]//@src | .//div[@class="post entry-content "]//li[@class="attachment"]//a[img]/@href | .//div[@itemprop="commentText"]//a[@class="bbc_url"]//@href | .//div[@itemprop="commentText"]//a[@class="bbc_url"]//@href | .//div[@id="gifv"]//video/source/@src'







#start_requests
headers_1 = {
   'authority': 'www.bleepingcomputer.com',
   'pragma': 'no-cache',
   'cache-control': 'no-cache',
   'origin': 'https://www.bleepingcomputer.com',
   'upgrade-insecure-requests': '1',
   'content-type': 'application/x-www-form-urlencoded',
   'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36',
   'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
   'referer': 'https://www.bleepingcomputer.com/forums/',
   'accept-encoding': 'gzip, deflate, br',
   'accept-language': 'en-US,en;q=0.9',
   'cookie': '__cfduid=d6d13be7eac6a6deac4d04a4cf7be68671537360685; _ga=GA1.2.1372707640.1537360689; _gid=GA1.2.565837778.1537360689; switch-synchronised=1; _fsuid=06e21a82-4f6a-4f91-807c-a4a83ac96764; __ds=1; __wl=0; __lb=0; __cwl=1; _fsloc=?i=IN&c=QmVuZ2FsdXJ1; __SW=befncap24b5saoku8be0; __gads=ID=6406e059ea9c0b2b:T=1537360693:S=ALNI_MbF2OxQxXa_Kdn8X6JVRMHirWzs2Q; __qca=P0-1220576166-1537360693561; session_id=c4a3ce02bfc2833214d54a52ccf11933; _fssid=649c0c5a-0518-44fa-b46d-6f35a1dfb3e5; coppa=0; modtids=%2C; member_id=0; pass_hash=0; ipsconnect_d4dc7770bea1bfd6f98c2a1e9e3a93ea=0; _gat_UA-91740-1=1',
}

data_1 = {
 'auth_key': '880ea6a14ea49e853634fbdc5015a024',
 'referer': 'https://www.bleepingcomputer.com/forums/',
 'ips_username': 'inqspdr',
 'ips_password': 'Inq2018.',
 'rememberMe': '1'
}



#parse_1st
cookies_2 = {
    '__cfduid': 'd92eb879485546001a832b1a6f61f94eb1537350687',
    '_ga': 'GA1.2.2026653359.1537350691',
    '_gid': 'GA1.2.1402923328.1537350691',
    '_fsuid': '48a73bd0-b3ed-4e49-82af-eb4d73b549b1',
    '__ds': '1',
    '__wl': '0',
    '__lb': '0',
    '__cwl': '1',
    '_fsloc': '?i=IN&c=Q2hlbm5haQ==',
    '__gads': 'ID=4134f1e7539ca051:T=1537350699:S=ALNI_MaqwP8elnZ1PH5NP0pJuXxHi-kDvg',
    '__qca': 'P0-77586324-1537350700254',
    '__SW': 'beflg37qs9nsav1fpck0',
    'member_id': '0',
    'pass_hash': '0',
    'ipsconnect_d4dc7770bea1bfd6f98c2a1e9e3a93ea': '0',
    'toggleSBlocks': '%2Crecent20topics%2Clatestnews%2C',
    'switch-synchronised': '1',
    'session_id': '69c17073ac98bc0c739689786909a777',
    'coppa': '0',
    'modtids': '%2C',
    '_fssid': 'c0251e2d-3b67-4a7f-ae9e-da8401e30366',
}
headers_2 = {
    'Host': 'www.bleepingcomputer.com',
    'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:47.0) Gecko/20100101 Firefox/47.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
    'Connection': 'keep-alive',
    'Cache-Control': 'max-age=0',
}
#parse_next
cookies_3 = {
    '__cfduid': 'd92eb879485546001a832b1a6f61f94eb1537350687',
    '_ga': 'GA1.2.2026653359.1537350691',
    '_gid': 'GA1.2.1402923328.1537350691',
    '_fsuid': '48a73bd0-b3ed-4e49-82af-eb4d73b549b1',
    '__ds': '1',
    '__wl': '0',
    '__lb': '0',
    '__cwl': '1',
    '_fsloc': '?i=IN&c=Q2hlbm5haQ==',
    '__gads': 'ID=4134f1e7539ca051:T=1537350699:S=ALNI_MaqwP8elnZ1PH5NP0pJuXxHi-kDvg',
    '__qca': 'P0-77586324-1537350700254',
    '__SW': 'beflg37qs9nsav1fpck0',
    'member_id': '1103219',
    'pass_hash': '4873a506edc8f32fe2a8881a7dcc190a',
    'ipsconnect_d4dc7770bea1bfd6f98c2a1e9e3a93ea': '1',
    'toggleSBlocks': '%2Crecent20topics%2Clatestnews%2C',
    'switch-synchronised': '1',
    'session_id': '68ccb898055aa1a14dbb350035f08cf6',
    'coppa': '0',
    'modtids': '%2C',
    'rteStatus': 'rte',
}

headers_3 = {
    'Host': 'www.bleepingcomputer.com',
    'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:47.0) Gecko/20100101 Firefox/47.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
    'Connection': 'keep-alive',
    'Cache-Control': 'max-age=0',
}


#parse_threads


cookies_ = {
    '__cfduid': 'd92eb879485546001a832b1a6f61f94eb1537350687',
    '_ga': 'GA1.2.2026653359.1537350691',
    '_gid': 'GA1.2.1402923328.1537350691',
    '_fsuid': '48a73bd0-b3ed-4e49-82af-eb4d73b549b1',
    '__ds': '1',
    '__wl': '0',
    '__lb': '0',
    '__cwl': '1',
    '_fsloc': '?i=IN&c=Q2hlbm5haQ==',
    '__gads': 'ID=4134f1e7539ca051:T=1537350699:S=ALNI_MaqwP8elnZ1PH5NP0pJuXxHi-kDvg',
    '__qca': 'P0-77586324-1537350700254',
    '__SW': 'beflg37qs9nsav1fpck0',
    'member_id': '1103219',
    'pass_hash': '4873a506edc8f32fe2a8881a7dcc190a',
    'ipsconnect_d4dc7770bea1bfd6f98c2a1e9e3a93ea': '1',
    'toggleSBlocks': '%2Crecent20topics%2Clatestnews%2C',
    'switch-synchronised': '1',
    'session_id': '68ccb898055aa1a14dbb350035f08cf6',
    'coppa': '0',
    'modtids': '%2C',
    'rteStatus': 'rte',

}

headers_ = {
    'Host': 'www.bleepingcomputer.com',
    'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:47.0) Gecko/20100101 Firefox/47.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
    'Connection': 'keep-alive',
    'Cache-Control': 'max-age=0',
}


#authors headers and coockies
#start_requesr  authors
headers_a1 = {
   'authority': 'www.bleepingcomputer.com',
   'pragma': 'no-cache',
   'cache-control': 'no-cache',
   'origin': 'https://www.bleepingcomputer.com',
   'upgrade-insecure-requests': '1',
   'content-type': 'application/x-www-form-urlencoded',
   'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36',
   'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
   'referer': 'https://www.bleepingcomputer.com/forums/',
   'accept-encoding': 'gzip, deflate, br',
   'accept-language': 'en-US,en;q=0.9',
   'cookie': '__cfduid=d6d13be7eac6a6deac4d04a4cf7be68671537360685; _ga=GA1.2.1372707640.1537360689; _gid=GA1.2.565837778.1537360689; switch-synchronised=1; _fsuid=06e21a82-4f6a-4f91-807c-a4a83ac96764; __ds=1; __wl=0; __lb=0; __cwl=1; _fsloc=?i=IN&c=QmVuZ2FsdXJ1; __SW=befncap24b5saoku8be0; __gads=ID=6406e059ea9c0b2b:T=1537360693:S=ALNI_MbF2OxQxXa_Kdn8X6JVRMHirWzs2Q; __qca=P0-1220576166-1537360693561; session_id=c4a3ce02bfc2833214d54a52ccf11933; _fssid=649c0c5a-0518-44fa-b46d-6f35a1dfb3e5; coppa=0; modtids=%2C; member_id=0; pass_hash=0; ipsconnect_d4dc7770bea1bfd6f98c2a1e9e3a93ea=0; _gat_UA-91740-1=1',
}

data_a1 = {
 'auth_key': '880ea6a14ea49e853634fbdc5015a024',
 'referer': 'https://www.bleepingcomputer.com/forums/',
 'ips_username': 'inqspdr',
 'ips_password': 'Inq2018.',
 'rememberMe': '1'
}

#parse_1st authors

cookies_a2 = {
    '__cfduid': 'd92eb879485546001a832b1a6f61f94eb1537350687',
    '_ga': 'GA1.2.2026653359.1537350691',
    '_gid': 'GA1.2.1402923328.1537350691',
    '_fsuid': '48a73bd0-b3ed-4e49-82af-eb4d73b549b1',
    '__ds': '1',
    '__wl': '0',
    '__lb': '0',
    '__cwl': '1',
    '_fsloc': '?i=IN&c=Q2hlbm5haQ==',
    '__gads': 'ID=4134f1e7539ca051:T=1537350699:S=ALNI_MaqwP8elnZ1PH5NP0pJuXxHi-kDvg',
    '__qca': 'P0-77586324-1537350700254',
    '__SW': 'beflg37qs9nsav1fpck0',
    'member_id': '0',
    'pass_hash': '0',
    'ipsconnect_d4dc7770bea1bfd6f98c2a1e9e3a93ea': '0',
    'toggleSBlocks': '%2Crecent20topics%2Clatestnews%2C',
    'switch-synchronised': '1',
    'session_id': '69c17073ac98bc0c739689786909a777',
    'coppa': '0',
    'modtids': '%2C',
    '_fssid': 'c0251e2d-3b67-4a7f-ae9e-da8401e30366',
}

headers_a2 = {
    'Host': 'www.bleepingcomputer.com',
    'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:47.0) Gecko/20100101 Firefox/47.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
    'Connection': 'keep-alive',
    'Cache-Control': 'max-age=0',
}

#parse_next authors

cookies_a3 = {
    '__cfduid': 'd92eb879485546001a832b1a6f61f94eb1537350687',
    '_ga': 'GA1.2.2026653359.1537350691',
    '_gid': 'GA1.2.1402923328.1537350691',
    '_fsuid': '48a73bd0-b3ed-4e49-82af-eb4d73b549b1',
    '__ds': '1',
    '__wl': '0',
    '__lb': '0',
    '__cwl': '1',
    '_fsloc': '?i=IN&c=Q2hlbm5haQ==',
    '__gads': 'ID=4134f1e7539ca051:T=1537350699:S=ALNI_MaqwP8elnZ1PH5NP0pJuXxHi-kDvg',
    '__qca': 'P0-77586324-1537350700254',
    '__SW': 'beflg37qs9nsav1fpck0',
    'member_id': '1103219',
    'pass_hash': '4873a506edc8f32fe2a8881a7dcc190a',
    'ipsconnect_d4dc7770bea1bfd6f98c2a1e9e3a93ea': '1',
    'toggleSBlocks': '%2Crecent20topics%2Clatestnews%2C',
    'switch-synchronised': '1',
    'session_id': '68ccb898055aa1a14dbb350035f08cf6',
    'coppa': '0',
    'modtids': '%2C',
    'rteStatus': 'rte',
}

headers_a3 = {
    'Host': 'www.bleepingcomputer.com',
    'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:47.0) Gecko/20100101 Firefox/47.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
    'Connection': 'keep-alive',
    'Cache-Control': 'max-age=0',
}
